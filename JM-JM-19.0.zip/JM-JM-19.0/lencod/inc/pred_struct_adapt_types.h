/*!
 ***************************************************************************
 * \file
 *    pred_struct_adapt_types.h
 *
 * \author
 *    Athanasios Leontaris           <aleon@dolby.com>   
 *
 * \date
 *    July 21, 2009
 *
 * \brief
 *    Header file for adaptive prediction structure types
 **************************************************************************
 */

#ifndef _PRED_STRUCT_ADAPT_TYPES_H_
#define _PRED_STRUCT_ADAPT_TYPES_H_



#endif
